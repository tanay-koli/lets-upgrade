#include <iostream>

using namespace std;

int main()
{   
    int num;
    cout<<"Enter A Number : ";
    cin>>num;
        for(int i=2;i<num;i++ )
        {
            if (num%i == 0)
            {   
                cout << num << " is not a prime number. ";
                break;
            }
            else if (num == i+1)
            {
                cout << num << " is a prime number. ";
            }
            else if (num==2)
            {
                cout << num << " is a prime number. ";
            }   
        }

    return 0;
}


